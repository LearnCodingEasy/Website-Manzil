"use strict";console.log("Yes");
//# sourceMappingURL=script.js.map
